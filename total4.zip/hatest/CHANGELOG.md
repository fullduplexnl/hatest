## 0.0.1
- Eerste versie van hatest (Apache 2.4 + CGI)
