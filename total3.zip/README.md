# my-ha-addons

dit is een test van een update

ik heb nu een regel toegevoegd

En nog eentje

En nog een!
